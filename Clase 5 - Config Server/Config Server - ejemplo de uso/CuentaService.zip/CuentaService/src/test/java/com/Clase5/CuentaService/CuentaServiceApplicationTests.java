package com.Clase5.CuentaService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CuentaServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
